require("dotenv").config();
const express = require("express");
const session = require("express-session");
const cookieParser = require("cookie-parser");
const Parser = require("rss-parser");
const fs = require("fs");
const path = require("path");

const app = express();
const PORT = process.env.PORT || 3000;
const parser = new Parser({
  timeout: 15000,
  headers: { "User-Agent": "24-7Updates/1.0 news-reader" },
  customFields: {
    item: [
      ["media:content", "mediaContent", { keepArray: true }],
      ["media:thumbnail", "mediaThumbnail", { keepArray: true }],
      ["content:encoded", "contentEncoded"]
    ]
  }
});
const DATA_DIR = path.join(__dirname, "data");
const POSTS_FILE = path.join(DATA_DIR, "posts.json");
fs.mkdirSync(DATA_DIR, { recursive: true });
if (!fs.existsSync(POSTS_FILE)) fs.writeFileSync(POSTS_FILE, "[]", "utf8");

app.use(express.json({ limit: "1mb" }));
app.use(express.urlencoded({ extended: true }));
app.use(cookieParser());
app.use(session({
  secret: process.env.SESSION_SECRET || "change-this-secret-before-deploying",
  resave: false,
  saveUninitialized: false,
  cookie: {
    httpOnly: true,
    sameSite: "lax",
    secure: process.env.NODE_ENV === "production",
    maxAge: 8 * 60 * 60 * 1000
  }
}));

app.get("/", (req, res) => res.sendFile(path.join(__dirname, "index.html")));

const FEEDS = [
  { category: "Duniya", name: "Al Jazeera", url: "https://www.aljazeera.com/xml/rss/all.xml" },
  { category: "Wasanni", name: "BBC Sport", url: "https://feeds.bbci.co.uk/sport/rss.xml?edition=uk" },
  { category: "Wasanni", name: "ESPN", url: "https://www.espn.com/espn/rss/news" },
  { category: "Fasaha", name: "The Verge", url: "https://www.theverge.com/rss/index.xml" },
  { category: "Nishaɗi", name: "The Guardian Culture", url: "https://www.theguardian.com/culture/rss" }
];

function readPosts() {
  try {
    const posts = JSON.parse(fs.readFileSync(POSTS_FILE, "utf8"));
    return Array.isArray(posts) ? posts : [];
  } catch {
    return [];
  }
}
function writePosts(posts) {
  fs.writeFileSync(POSTS_FILE, JSON.stringify(posts, null, 2), "utf8");
}
function requireAdmin(req, res, next) {
  if (req.session && req.session.admin === true) return next();
  return res.status(401).json({ error: "Dole ne ka shiga asusun admin." });
}
function stripHtml(value = "") {
  return String(value)
    .replace(/<!\[CDATA\[|\]\]>/g, "")
    .replace(/<script[\s\S]*?<\/script>/gi, " ")
    .replace(/<style[\s\S]*?<\/style>/gi, " ")
    .replace(/<[^>]*>/g, " ")
    .replace(/&nbsp;/gi, " ")
    .replace(/&amp;/gi, "&")
    .replace(/&quot;/gi, '"')
    .replace(/&#39;/gi, "'")
    .replace(/\s+/g, " ")
    .trim();
}
function findImage(item) {
  if (item.enclosure && item.enclosure.url) return item.enclosure.url;
  const candidates = [
    item.mediaContent, item.mediaThumbnail, item["media:content"], item["media:thumbnail"]
  ].flat().filter(Boolean);
  for (const c of candidates) {
    if (typeof c === "string" && /^https?:\/\//i.test(c)) return c;
    if (c && c.url) return c.url;
    if (c && c.$ && c.$.url) return c.$.url;
  }
  const html = [item.contentEncoded, item.content, item.summary, item.description].filter(Boolean).join(" ");
  const match = html.match(/<img\b[^>]*\bsrc=["']([^"']+)["']/i);
  if (match && /^https?:\/\//i.test(match[1])) return match[1];
  return "";
}

// Free best-effort English-to-Hausa translation. The public service can rate-limit
// requests; if it fails, the original text is kept rather than breaking the site.
const translationCache = new Map();
async function translateToHausa(text) {
  const original = stripHtml(text);
  if (!original || !process.env.TRANSLATE_NEWS || process.env.TRANSLATE_NEWS.toLowerCase() === "false") return original;
  if (/[ƙƘɗƊɓƁ]|(?:\b(?:da|kuma|amma|wannan|yanzu|Najeriya|wasanni)\b)/i.test(original)) return original;
  const key = original.slice(0, 450);
  if (translationCache.has(key)) return translationCache.get(key);
  try {
    const endpoint = process.env.TRANSLATE_URL || "https://api.mymemory.translated.net/get";
    const url = new URL(endpoint);
    url.searchParams.set("q", key);
    url.searchParams.set("langpair", "en|ha");
    const response = await fetch(url, { signal: AbortSignal.timeout(8000) });
    if (!response.ok) throw new Error("Translation service unavailable");
    const data = await response.json();
    const translated = stripHtml(data && data.responseData && data.responseData.translatedText);
    const result = translated && data.responseStatus === 200 ? translated : original;
    translationCache.set(key, result);
    if (translationCache.size > 500) translationCache.delete(translationCache.keys().next().value);
    return result;
  } catch (err) {
    console.warn("Fassarar Hausa ta kasa a wannan lokaci:", err.message);
    return original;
  }
}

let cachedAutomatic = [];
let lastFeedRefresh = 0;
let refreshingFeeds = false;
async function refreshFeeds() {
  if (refreshingFeeds) return;
  refreshingFeeds = true;
  try {
    const results = await Promise.allSettled(FEEDS.map(async feed => {
      const parsed = await parser.parseURL(feed.url);
      const items = await Promise.all((parsed.items || []).slice(0, 12).map(async item => {
        const rawTitle = stripHtml(item.title || "Sabon labari");
        const rawDescription = stripHtml(item.contentSnippet || item.summary || item.contentEncoded || item.content || item.description || "");
        const [title, description] = await Promise.all([
          translateToHausa(rawTitle),
          translateToHausa(rawDescription.slice(0, 450))
        ]);
        return {
          id: `${feed.name}-${item.guid || item.link || rawTitle}`,
          title: title || rawTitle,
          description: description || rawDescription,
          url: item.link || "#",
          image: findImage(item),
          category: feed.category,
          // Keep the source internally, but the public page does not display it.
          source: feed.name,
          date: item.isoDate || item.pubDate || new Date().toISOString(),
          manual: false
        };
      }));
      return items;
    }));
    cachedAutomatic = results.flatMap(r => r.status === "fulfilled" ? r.value : []);
    lastFeedRefresh = Date.now();
  } finally {
    refreshingFeeds = false;
  }
}

app.get("/api/news", async (req, res) => {
  if (!lastFeedRefresh || Date.now() - lastFeedRefresh > 5 * 60 * 1000) {
    await refreshFeeds();
  }
  const manual = readPosts().map(p => ({ ...p, source: "24/7Updates", manual: true }));
  const category = String(req.query.category || "").toLowerCase();
  let all = [...manual, ...cachedAutomatic];
  if (category && category !== "duk" && category !== "all") {
    all = all.filter(n => (n.category || "").toLowerCase() === category);
  }
  all.sort((a, b) => new Date(b.date || 0) - new Date(a.date || 0));
  res.set("Cache-Control", "no-store");
  res.json({
    items: all.slice(0, 80),
    updatedAt: lastFeedRefresh ? new Date(lastFeedRefresh).toISOString() : new Date().toISOString()
  });
});

app.post("/api/admin/login", (req, res) => {
  const password = String(req.body.password || "");
  const expected = process.env.ADMIN_PASSWORD || "change-this-password";
  if (expected === "change-this-password" || password !== expected) {
    return res.status(401).json({ error: "Ba a karɓi kalmar sirri ba. Saita ADMIN_PASSWORD a hosting." });
  }
  req.session.admin = true;
  res.json({ ok: true });
});
app.post("/api/admin/logout", (req, res) => {
  req.session.destroy(() => res.json({ ok: true }));
});
app.get("/api/admin/me", (req, res) => res.json({ loggedIn: !!(req.session && req.session.admin) }));
app.post("/api/admin/posts", requireAdmin, (req, res) => {
  const { title, description, category, image, url } = req.body || {};
  if (!title || !description || !category) {
    return res.status(400).json({ error: "Cika kanun labari, bayani da rukuni." });
  }
  const posts = readPosts();
  const post = {
    id: `manual-${Date.now()}`,
    title: String(title).slice(0, 180),
    description: String(description).slice(0, 3000),
    category: String(category).slice(0, 60),
    image: String(image || "").slice(0, 1000),
    url: String(url || "").slice(0, 1000),
    source: "24/7Updates",
    date: new Date().toISOString(),
    manual: true
  };
  posts.unshift(post);
  writePosts(posts);
  res.json({ ok: true, post });
});
app.delete("/api/admin/posts/:id", requireAdmin, (req, res) => {
  const posts = readPosts();
  const updated = posts.filter(p => p.id !== req.params.id);
  if (updated.length === posts.length) return res.status(404).json({ error: "Ba a sami labarin ba." });
  writePosts(updated);
  res.json({ ok: true });
});
app.get("*", (req, res) => res.sendFile(path.join(__dirname, "index.html")));
app.listen(PORT, () => console.log(`24/7Updates is running on port ${PORT}`));
